import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Image;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Font;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.Icon;

public class GUI extends JFrame{
    //Lógica de la apicación
    private Logica l;

    //Paneles
    private JPanel panelBanner;
    private JPanel panelJuego;

    //Botones
    private JButton [][] botones;

    //Iconos
    private ImageIcon iconoInicialRedimensionado;
    private ImageIcon iconoXRedimensionado;
    private ImageIcon iconoORedimensionado;

    //Labels
    private JLabel banner;

    //Restricciones para cada label
    private GridBagConstraints constraintsBanner;
    private GridBagConstraints constraintsJuego;

    //Constructor
    public GUI() {
        super("TaTeTi"); //Establece nombre de la ventana
        l = new Logica();
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(new Dimension(800,800));
        inicializarGUI();
        setLocationRelativeTo(null); //Establece que la ventana aparezca por default en el centro de la pantalla

        /*
        El método setLocationRelativeTo() coloca la ventana en una posición relativa a un componente que le paso como parámetro. 
        Pasándole null como parámetro, coloca a la ventana en el centro de la pantalla.
         */

        setVisible(true); //Hago visible la ventana en la pantalla
    }

    //Método para inicialiazar las componentes
    private void inicializarGUI() {
        //GridBagLayout es como GridLayout solo que permite modificar cada cuadrilla individualmente (tamaño y demás)
        this.setLayout(new GridBagLayout());

        banner = new JLabel(new ImageIcon("banner.png"));

        //Armado del panel del titulo
        panelBanner = new JPanel(new GridBagLayout());
        panelBanner.add(banner);

        //Armado del panel del juego
        panelJuego = new JPanel(new GridLayout(3,3));
        inicializarIconos();
        inicializarBotones();

        //Creando restricciones para el panel del banner
        constraintsBanner = new GridBagConstraints();
        constraintsBanner.gridy = 0; //Indica fila donde va el elemento
        constraintsBanner.gridwidth = 1; //Cantidad de columnas que va a ocupar (tamaño)
        constraintsBanner.gridheight = 1; //Cantidad de filar que va a ocupar (tamaño)
        constraintsBanner.weighty = 0.25; // Peso vertical para centrar, indica como distribuir el espacio adicional que queda en el contenedor
        constraintsBanner.weightx = 1.0;
        constraintsBanner.fill = GridBagConstraints.BOTH; //El panel se redimensiona horizontal como verticalmente para ocupar todo el espacio disponible de su celda

        //Creando restricciones para el panel del juego
        constraintsJuego = new GridBagConstraints();
        constraintsJuego.gridy = 1;
        constraintsJuego.gridwidth = 1; 
        constraintsJuego.gridheight = 1;
        constraintsJuego.weighty = 1.0;
        constraintsJuego.weightx = 1.0;
        constraintsJuego.fill = GridBagConstraints.BOTH;

        //Agregado de los paneles principales al contentpane
        this.add(panelBanner, constraintsBanner);
        this.add(panelJuego, constraintsJuego);
        this.setResizable(false);
    }

    //Método para inicializar los botones que representan las celdas del juego
    private void inicializarBotones() {
        //Creo la matriz de botones
        botones = new JButton[3][3];
        //Por cada botón de la matriz:
        for (int f = 0; f < botones.length; f++) {
            for (int c = 0; c < botones[0].length; c++) {
                //Creo el botón
                botones[f][c] = new JButton();
                //Le doy dimension al botón para que no cambie de tamaño tras insertarle un icono
                botones[f][c].setPreferredSize(new Dimension(1,1));
                //Establezco su icono
                botones[f][c].setIcon(iconoInicialRedimensionado);
                //Seteo el action command "i,j"
                botones[f][c].setActionCommand(f+","+c);
                //Establezco su oyente
                botones[f][c].addActionListener(new OyenteBotonCelda());
                //Agrego el botón al panel del juego
                panelJuego.add(botones[f][c]);
            }
        }
    }

    //Método que prepara los iconos adecuadamente para poder ser seteados en los botones
    private void inicializarIconos() {
        //Redimensiono la imagen del icono inicial
        ImageIcon iconoInicial = new ImageIcon("iconoInicial.jpg");
        Image imagenInicialRedimensionada = iconoInicial.getImage().getScaledInstance(264, 200, Image.SCALE_SMOOTH);
        iconoInicialRedimensionado = new ImageIcon(imagenInicialRedimensionada);
        iconoInicialRedimensionado.setDescription("I");

        //Redimensiono la imagen del icono X
        ImageIcon iconoX = new ImageIcon("iconoX.png");
        Image imagenXRedimensionada = iconoX.getImage().getScaledInstance(264, 200, Image.SCALE_SMOOTH);
        iconoXRedimensionado = new ImageIcon(imagenXRedimensionada);
        iconoXRedimensionado.setDescription("X");

        //Redimensiono la imagen del icono O
        ImageIcon iconoO = new ImageIcon("iconoO.png");
        Image imagenORedimensionada = iconoO.getImage().getScaledInstance(264, 200, Image.SCALE_SMOOTH);
        iconoORedimensionado = new ImageIcon(imagenORedimensionada);
        iconoORedimensionado.setDescription("O");
    }

    private boolean chequearGanador(String jugador) {
        //Booleanos para chequear si hay ganador en columnas o diagonales
        boolean tresEnColumna = false;
        boolean tresEnDiagonal = false;

        //Servirán para obtener el nombre del icono del boton
        Icon iconoBoton;
        String nombreIcono;

        /*----------------Lógica para encontrar ganador en grilla----------------*/

        int contadorColumnas1 = 0;
        int contadorColumnas2 = 0;
        int contadorColumnas3 = 0;
        int contadorDiagonal1 = 0;
        int contadorDiagonal2 = 0;
        int contadorFilas = 0;

        //Seteo auxiliares que servirán para identificar en que columna esta el icono
        int auxCol1 = 0; //Identifica los elementos que están en la columna de la izquierda
        int auxCol2 = 1; //Identifica los elementos que están en la columna del centro
        int auxCol3 = 2; //Identifica los elementos que están en la columna de la derecha

        //Buscador de 3 consecutivos en filas, columnas o diagonales
        for (int f = 0; f < l.cantidadFilas() && contadorFilas < 3
        && !tresEnDiagonal && !tresEnColumna; f++) {
            contadorFilas = 0; //Al comenzar una nueva fila, reestablezco el contador
            for (int c = 0; c < l.cantidadColumnas() && contadorFilas < 3
            && !tresEnDiagonal && !tresEnColumna; c++) {
                if (l.obtenerCelda(f,c)) {
                    iconoBoton = botones[f][c].getIcon();
                    nombreIcono = ((ImageIcon) iconoBoton).getDescription();
                    if (nombreIcono.equals(jugador)) {
                        contadorFilas++;
                        //Sumo elementos que estén en cualquiera de las diagonales
                        if (f == c) { //Sirve para identificar cuando sumar elementos en la diagonal de izq a der
                            if (f == 1) { //Si hay un elemento en el medio del tablero, sumo en ambos contadores porque está en ambas diagonales
                                contadorDiagonal2++;
                            }
                            contadorDiagonal1++;
                        }
                        if ((f == 2 && c == 0) || (f == 0 && c == 2)) { //Sirve para identificar cuando sumar elementos en la diagonal de der a izq
                            contadorDiagonal2++;
                        }
                        //Sumo los elementos que estén en la misma columna
                        if (auxCol1 == c) { 
                            contadorColumnas1++;
                        }
                        if (auxCol2 == c) {
                            contadorColumnas2++;
                        }
                        if (auxCol3 == c) {
                            contadorColumnas3++;
                        }
                    }
                }
                tresEnColumna = contadorColumnas1 == 3 || contadorColumnas2 == 3 || contadorColumnas3 == 3;
                tresEnDiagonal = contadorDiagonal1 == 3 || contadorDiagonal2 == 3;
            }
        }
        return contadorFilas == 3 || tresEnColumna || tresEnDiagonal;
    }

    private void reiniciarJuego() {
        reiniciarBotones();
        reiniciarMatrizLogica();
    }

    private void reiniciarMatrizLogica() {
        l = new Logica();
    }

    private void reiniciarBotones() {
        for (int f = 0; f < botones.length; f++) {
            for (int c = 0; c < botones[0].length; c++) {
                botones[f][c].setIcon(iconoInicialRedimensionado);
            }
        }
    }

    //Oyente de botones de celdas
    private class OyenteBotonCelda implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String indices = e.getActionCommand(); //obtengo el identificador del boton seleccionado
            String[] fyc= indices.split(",");
            int f=Integer.parseInt(fyc[0]); //obtengo nro de fila del botón
            int c=Integer.parseInt(fyc[1]); //obtengo nro de columna del botón

            //Lógica tras presionar el botón
            if (!l.obtenerCelda(f,c)) {
                l.seleccionarCelda(f,c);
                l.incrementarMovimientos();
                l.cambiarJugador();
                //Como cambio de jugador, debo negarlo en el if para trabajar con el que inicialmente tocó el botón
                if(!l.obtenerJugador()) {
                    //Si presiona el jugador 1
                    botones[f][c].setIcon(iconoXRedimensionado);
                    if (l.cantMovimientos() > 4 && chequearGanador("X")) {
                        //Muestro el mensaje de ganador
                        JOptionPane.showMessageDialog(null, "¡JUGADOR 1 HA GANADO!", "FELICITACIONES", JOptionPane.INFORMATION_MESSAGE);
                        reiniciarJuego();
                    }
                } else {
                    //Si presiona el jugador 2
                    botones[f][c].setIcon(iconoORedimensionado);
                    if (l.cantMovimientos() > 4 && chequearGanador("O")) {
                        //Muestro el mensaje de ganador
                        JOptionPane.showMessageDialog(null, "¡JUGADOR 2 HA GANADO!", "FELICITACIONES", JOptionPane.INFORMATION_MESSAGE);
                        reiniciarJuego();
                    }
                }
            }

            //Si se realizan 9 movimientos y no ha habido ganador, el juego ha terminado en empate
            if (l.cantMovimientos() == 9) {
                JOptionPane.showMessageDialog(null, "¡HAN EMPATADO!", "EMPATE", JOptionPane.INFORMATION_MESSAGE);
                reiniciarJuego();
            }
        }
    }
}