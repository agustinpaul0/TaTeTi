public class Logica {
    //Atributos de instancia
    private int movimientos;
    private boolean jugador;
    private boolean celdas[][];

    //Constructor
    public Logica() {
        movimientos = 0; //Representa la cantidad de movimientos realizados en el juego, se necesitan mínimo 5 para ganar
        jugador = true; //True representa al jugador 1
        celdas = new boolean[3][3]; //Crea e inicializa la matriz de botones en falso
        for (int f = 0; f < cantidadFilas(); f++) {
            for (int c = 0; c < cantidadColumnas(); c++) {
                celdas[f][c] = false;
            }
        }
    }

    //Consultas
    public int cantidadFilas() {
        return celdas.length;
    }

    public int cantidadColumnas() {
        return celdas[0].length;
    }

    public boolean obtenerCelda(int f, int c) {
        //Requiere f y c válidos (que estén dentro del rango de la matriz)
        //Si la celda ya fue presionada por un jugador retorna true, de lo contrario, false
        return celdas[f][c]; 
    }

    public boolean obtenerJugador() {
        //True se corresponde con el jugador 1
        return jugador;
    }

    public int cantMovimientos() {
        return movimientos;
    }

    //Comandos
    public void seleccionarCelda(int f, int c) {
        //Requiere f y c válidos (que estén dentro del rango de la matriz de booleanos)
        celdas[f][c] = true;
    }

    public void incrementarMovimientos() { 
        //Cada vez que un jugador juegue, aumenta en 1 el número de movimientos realizados
        movimientos++;
    }

    public void cambiarJugador() {
        //Cambia el jugador que debe jugar
        jugador = !jugador;
    }
}